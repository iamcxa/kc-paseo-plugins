---
commissioned-by: spacedock@0.27.3
entity-type: task
id-style: slug
state: .spacedock-state
stages:
  states:
    - name: backlog
      initial: true
    - name: validation
      gate: true
    - name: done
      terminal: true
---
# Fictional workflow
