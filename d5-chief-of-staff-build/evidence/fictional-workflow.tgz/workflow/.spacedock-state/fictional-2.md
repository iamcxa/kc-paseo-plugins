---
id: fictional-2
title: Fictional release 2
status: validation
gates:
    version: 1
    records:
        - id: gate:fictional-2:validation
          stage: validation
          attempts:
            - id: gate-attempt:fictional-2-validation-1
              briefing:
                id: briefing:fictional-2:validation:attempt-1:revision-1
                digest: sha256:465f0d80121a011464e9db14fbf20cd592ee6b2d1f40da9b6845431af1e9c08f
                room-ref: ./fictional-2/review/validation/briefing-1
---
Fictional task only.
